package main;
//import java.util.Map;

import polyBasis.*;
public class Exe {
	
	//1000000000000011 = x^15+x+1
	//f(x) = x^N, g(x) = x^M - (15,15) - ������� �������
	
	public static void main(String[] args) {
		long start_timer = System.currentTimeMillis();
		int n = 15;
		// TODO Auto-generated method stub
		/*Gal gal = new Gal("10").pow(new Myr("2"));
		System.out.println(gal.toString());*/
		
		showBFandBGCoordFuncProperties();
		
		System.out.println("time taken: " + (System.currentTimeMillis() - start_timer) + " ms");
	}
	
	static void showBFandBGCoordFuncProperties() {
		int n = 15;
		
		BooleanFunction bf = new BooleanFunction("bf");
		bf.init('f', false);
		//bf.printTableOfAccordance();
		
		System.out.println("disbalance:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bf.coordinateFunctions[i].disbalance);
		System.out.println("deg:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bf.coordinateFunctions[i].deg);
		System.out.println("NL:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bf.coordinateFunctions[i].findNL());
		System.out.println("CorrImmun:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bf.coordinateFunctions[i].findCorrImmun());
		System.out.println("spreading:");
		for(int i=0; i<n; i++) {
			for(int j = 0;j<n; j++) {
				System.out.print(bf.coordinateFunctions[i].spreading[j] + "\t");
			}System.out.println();
		}
		System.out.println("Average spreading deviation:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bf.coordinateFunctions[i].avgSpreadingDeviation());
		
		bf.coordinateFunctions[0].test();
		
		/*BooleanFunction bg = new BooleanFunction("bg");
		bg.init('g', false);
		//bg.createCoordinateFunctions();
		//bf.printTableOfAccordance();
		
		System.out.println("disbalance:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bg.coordinateFunctions[i].disbalance);
		System.out.println("deg:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bg.coordinateFunctions[i].deg);
		System.out.println("NL:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bg.coordinateFunctions[i].findNL());
		System.out.println("CorrImmun:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bg.coordinateFunctions[i].findCorrImmun());
		System.out.println("Average spreading deviation:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bg.coordinateFunctions[i].avgSpreadingDeviation());*/
	}
	
	public void printBfSpreading() {
		BooleanFunction bf = new BooleanFunction("bf");
		bf.init('f', true);
		for(CoordinateFunction cf : bf.coordinateFunctions) {
			for(int spr : cf.spreading) {
				System.out.println(spr);
			}
			System.out.println();
		}
	}

}
