package test;

import junit

public class TestFurieTransformation {

}
