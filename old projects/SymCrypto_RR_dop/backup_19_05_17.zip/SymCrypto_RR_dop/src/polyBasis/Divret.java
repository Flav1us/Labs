package polyBasis;

public class Divret {
	Myr Q = new Myr("");
	Myr remainder = new Myr("");
}
