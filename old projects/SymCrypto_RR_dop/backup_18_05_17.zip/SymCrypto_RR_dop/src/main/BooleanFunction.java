package main;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

import polyBasis.Gal;
import polyBasis.Myr;
//������������ (n,n)-Bf, 6 �������, ������������ ������������
public class BooleanFunction {
	
	static final int n = 15;
	//static final int n = 15;
	static final int N = 2175/*==0x87F*/, M = 2176/*==0x880*/;
	//static final int N = 3/*==0x87F*/, M = 3/*==0x880*/;
	//static final int N =0x87F, M = 0x880;
	Map<boolean[], boolean[]> tableOfAccordance;
	CoordinateFunction[] coordinateFunctions;
	String instanceName;
	String storedTOAFilename;
	int deg; //� �������������, ��� ������� �� - ��� �������� �� �������� ������������ �������
	int avgSpreading;
	double[] avgSpreadingDeviation;
	
	
	public BooleanFunction(String instanceName) {
		this.instanceName = instanceName;
		//createTableOfAccordance();
		storedTOAFilename = "tableOfAccordance_"+instanceName+".bin";
		
	}
	
	void init(char type, boolean recalculateTOA) {
		//������ �������� �������, �������������� �� ������� ������������, ��� ����� ����������� �� ������ (storedTOAFilename).
		if (recalculateTOA == true) createTableOfAccordance(type);
		retrieveTOA();
		createCoordinateFunctions();
		this.deg = this.deg();
		System.out.println("calculating avgSpreadingDeviation");
		//this.avgSpreadingDeviation = this.avgSpreadingDeviation();
	}
	
	void retrieveTOA() {
		this.tableOfAccordance = retrieveMap(storedTOAFilename);
	}
	
	void createCoordinateFunctions() {
		this.coordinateFunctions = new CoordinateFunction[n];
		Map<boolean[], boolean[]> sortedTOA = BooleanFunction.sortByKey(this.tableOfAccordance);
		int ctr = 0;
		boolean[][] vals = new boolean[n][(int)Math.pow(2, n)];
		for(Map.Entry<boolean[], boolean[]> i : sortedTOA.entrySet()) {
			for(int j=0; j<n; j++) {	
				//this.coordinateFunctions[j].values[ctr] = i.getValue()[j];
				vals[j][ctr] = i.getValue()[j];
				//System.out.print((vals[j][ctr] == true)?'1':'0');
			}
			ctr++;
		}
		//System.out.print("Creating coordinate functions: ");
		for(int i=0; i<n; i++) {
			this.coordinateFunctions[i] = new CoordinateFunction(vals[i], n);
			//System.out.print('.');
		}
		//System.out.println();
	}
	
	/*void printCoordinateFunctions() {
		System.out.println();
		for(int i=0; i<n; i++) {
			for(int j=0; j<(int)Math.pow(2,n); j++) {
//				System.out.print(this.coordinateFunctions[i][j]==false ? 0 : 1);
				if(j%1000==0)System.out.print('.');
			}
			System.out.println();
		}
	}*/
	
	void createTableOfAccordance(char type) throws IllegalArgumentException {
		if (type != 'f' && type != 'g') throw new IllegalArgumentException("Illegal type. Should be 'f' or 'g'.");
		System.out.println("Wait 32 dots:");
		Map<boolean[], boolean[]> tableOA = new HashMap<>();
		String s;
		for(int i=0; i<(int)Math.pow(2,n); i++) {
			//System.out.println("kappa");
			//boolean[] x = new boolean[n], fx = new boolean[n];
			boolean[] x = new boolean[n];
			s = BooleanFunction.lpad(Integer.toBinaryString(i), n);
			//System.out.println(" " + s);
			for(int j=0; j<n; j++) {
				//x[j] = s.charAt(n-j-1)=='0' ? false : true;
				x[j] = s.charAt(j)=='0' ? false : true;
			}
			
			//System.out.println(s);
			/*for(int j = n - s.length()+1; j<n; j++) {
				x[j] = s.charAt(n-j)=='0' ? false : true;
				//fx[j] = s.charAt(n-j-1)=='0' ? false : true;
			}
			for(int j=0; j<n-s.length(); j++) {
				x[j] = false;
				//fx[j] = false;
			}*/
			//fx = f(x);
			//tableOA.put(x, fx);
			//System.out.println(f(x)[n]);
			if (type == 'f') tableOA.put(x, f(x));
			else if (type == 'g') tableOA.put(x, g(x));
			else throw new IllegalArgumentException("LABEL SHOULDNT APPEAR HERE! Illegal type. Should be 'f' or 'g'.");
			if(i%1000 == 1) System.out.print('.');
		}
		System.out.println();
		try {
			saveMap(tableOA, storedTOAFilename);
		} catch (IOException e) {
			System.out.println("couldn't save tableOfAccordance:\n" + e.getMessage());
		}
	}
	
	boolean[] f(boolean[] x) {
		boolean[] fx = new boolean[n];
		Gal x1 = Gal.booleanArrToGal(x);
		//System.out.println(" " + x1.toString());
		//System.out.println(x1.toPolyString());
		x1 = x1.pow(new Myr(Integer.toHexString(N)));
		//System.out.println("" + x1.toString());
		fx = x1.toBooleanArr();
		return fx;
	}
	
	boolean[] g(boolean[] x) {
		boolean[] gx = new boolean[n];
		Gal x1 = Gal.booleanArrToGal(x);
		x1 = x1.pow(new Myr(Integer.toHexString(M)));
		gx = x1.toBooleanArr();
		return gx;
	}
	
	void printTableOfAccordance() {
		//String s;
		Map<boolean[], boolean[]> sortedTOA = BooleanFunction.sortByKey(this.tableOfAccordance);
		//System.out.println(sortedTOA.size());
		//int ctr = 0;
		for(Map.Entry<boolean[], boolean[]> e : sortedTOA.entrySet()) {
			//ctr++; System.out.println(ctr);
			for(int i = 0; i<n; i++) {
				System.out.print(e.getKey()[i]==false ? 0 : 1);
			}
			System.out.print("\t");
			for(int i = 0; i<n; i++) {
				System.out.print(e.getValue()[i]==false ? 0 : 1);
			}
			System.out.print("\n");
		}
	}
	
	/*void checkTOA() {
		String s1;
		//for(Map.Entry<boolean[], boolean[]> e : this.tableOfAccordance.entrySet()) {
			for(int i=0; i<(int)Math.pow(2,n); i++) {
				//if(i%1024 == 1) System.out.print('.');
				s1 = BooleanFunction.lpad(Integer.toBinaryString(i), 15);
				System.out.println(s1 + "\t" + this.tableOfAccordance.get(new Gal(s1).toBooleanArr()));
			}
			System.out.println("OK");
		//}
	}*/
	
	public int deg() {
		//� �������������, ��� ������� �� - ��� �������� �� �������� ������������ �������
		int deg = 0;
		for(CoordinateFunction cf : this.coordinateFunctions) {
			if(cf.deg > deg) deg = cf.deg;
		}
		return deg;
	}
	
	public double[] avgSpreadingDeviation() {
		double[] avgSD = new double[n];
		int[] avgSpr = this.avgSpreading();
		for(int i=0; i<n; i++) avgSD[i] = (avgSpr[i] - n*Math.pow(2, n-1))/(n*Math.pow(2, n-1));
		return avgSD;
	}
	
	int[] avgSpreading() {
		//TODO TEST
		int k = 0;
		int[] avgSpr = new int[n];
		//int twoPowN = (int)Math.pow(2, n);
		//String t1, t2;
		boolean[] b1, b2, b;
		//int ctr = 0;
		for(int i=0; i<n; i++) {
			for(Map.Entry<boolean[], boolean[]> e : BooleanFunction.sortByKey(this.tableOfAccordance).entrySet()) {
				b1 = e.getKey().clone();
				b2 = b1.clone();
				b2[i] = b2[i] ^ true;
				System.out.println("b1: " + boolArrAsString(b1) + " " + boolArrAsString(this.tableOfAccordance.get(b1)) + "\tb2:" + boolArrAsString(b2) + boolArrAsString(this.tableOfAccordance.get(b2)));
				b = xorArrays(this.tableOfAccordance.get(b1), this.tableOfAccordance.get(b2));
				for(int j =0; j<b.length; j++) k+= ((b[i]==true)?1:0);
				//ctr++;
			}
			avgSpr[i]=k;
			k=0;
		}
		return avgSpr;
		
		/*int k = 0;
		int twoPowN = (int)Math.pow(2, n);
		String t1, t2;
		//String s;
		char[] chArr;
		for(int i=0; i<twoPowN; i++) {
			t1 = BooleanFunction.lpad(Integer.toBinaryString(i), n);
			chArr = t1.toCharArray();
			chArr[varNum] = ((t1.charAt(varNum)=='1') ? '0' : '1');
			t2 = String.valueOf(chArr);
			//System.out.println(t1 + " " + t2 + " " + this.values[Integer.parseInt(t1, 2)] + " " + this.values[Integer.parseInt(t2, 2)]);
			k+=(this.values[Integer.parseInt(t1, 2)] ^ this.values[Integer.parseInt(t2, 2)])==false ? 0 : 1;
		}
		return k;*/
	}
	
	public static String boolArrAsString(boolean[] b) {
		StringBuilder s = new StringBuilder();
		for(int i=0; i<b.length; i++) {
			//System.out.print(b[i]==false?'0':'1');
			s.append(b[i] == false ? '0' : '1');
		}
		//System.out.println();
		return s.toString();
	}
	
	public boolean[] xorArrays(boolean[] a, boolean[] b) throws IllegalArgumentException {
		if(a.length != b.length) throw new IllegalArgumentException("Array sizes should be equal: " + a.length + " != " + b.length);
		boolean[] res = new boolean[a.length];
		for(int i=0; i<res.length; i++) {
			res[i] = a[i] ^ b[i];
		}
		return res;
	}
	
	public static String lpad(String s, int n) {
		StringBuilder s1 = new StringBuilder();
		for(int i=0; i<n-s.length(); i++) {
			s1.append('0');
		}
		s1.append(s);
	    return s1.toString();  
	}
	
	//public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map) {
	public static Map<boolean[], boolean[]> sortByValue(Map<boolean[], boolean[]> map) {
	    return map.entrySet()
	              .stream()
	              //.sorted(Map.Entry.comparingByValue(Collections.reverseOrder()))
	              .sorted(Map.Entry.comparingByValue(new LexicographicComparator()))
	              .collect(Collectors.toMap(
	                Map.Entry::getKey, 
	                Map.Entry::getValue, 
	                (e1, e2) -> e1, 
	                LinkedHashMap::new
	              ));
	}
	
	public static Map<boolean[], boolean[]> sortByKey(Map<boolean[], boolean[]> map) {
	    return map.entrySet()
	              .stream()
	              //.sorted(Map.Entry.comparingByValue(Collections.reverseOrder()))
	              .sorted(Map.Entry.comparingByKey(new LexicographicComparator()))
	              .collect(Collectors.toMap(
	                Map.Entry::getKey, 
	                Map.Entry::getValue, 
	                (e1, e2) -> e1, 
	                LinkedHashMap::new
	              ));
	}
	
	
	public static void saveMap(Map<boolean[], boolean[]> map, String filename) throws IOException {
		try {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename));
			out.writeObject(map);
			out.close();
		} catch (FileNotFoundException e) {
			System.out.println("looks like file not found:\n" + e.getMessage());
		}
	}
	
	
	public static Map<boolean[], boolean[]> retrieveMap(String filename) {
		Map<boolean[], boolean[]> map = null;
		try {
	         FileInputStream fileIn = new FileInputStream(filename);
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         map = (Map<boolean[], boolean[]>) in.readObject();
	         in.close();
	         fileIn.close();
	      }catch(IOException i) {
	         i.printStackTrace();
	         return null;
	      }catch(ClassNotFoundException c) {
	         System.out.println("Map class not found");
	         c.printStackTrace();
	         return null;
	      }
		return map;
	}
	
	
}


class LexicographicComparator implements Comparator<boolean[]> {
    @Override
    public int compare(boolean[] a, boolean[] b) {
        for(int i=0; i<a.length; i++) {
        //for(int i=a.length-1; i>=0; i--) {
        	if (a[i] == false && b[i] == true) return -1;
        	else if (a[i] == true && b[i] == false) return 1;
        }
        return 0;
    }
}
