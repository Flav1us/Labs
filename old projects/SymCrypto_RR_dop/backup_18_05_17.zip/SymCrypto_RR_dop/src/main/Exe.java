package main;
import java.util.Map;

import polyBasis.*;
public class Exe {
	
	//1000000000000011 = x^15+x+1
	//f(x) = x^N, g(x) = x^M - (15,15) - ������� �������
	
	public static void main(String[] args) {
		long start_timer = System.currentTimeMillis();
		//int n = 15;
		// TODO Auto-generated method stub
		/*Gal gal = new Gal("10").pow(new Myr("2"));
		System.out.println(gal.toString());*/
		BooleanFunction bf = new BooleanFunction("bf");
		bf.init('f', false);
		//for(int i=0; i<bf.n; i++) System.out.println(bf.avgSpreadingDeviation[i]);
		boolean[] b = null;
		//for(int i=0; i<b.length; i++) b[i] = false;
		//b[14] = true;
		//System.out.println(BooleanFunction.boolArrAsString(bf.tableOfAccordance.get(b)));
		//bf.printTableOfAccordance();
		for(Map.Entry<boolean[], boolean[]> e : BooleanFunction.sortByKey(bf.tableOfAccordance).entrySet()) {
			System.out.println(BooleanFunction.boolArrAsString(e.getKey()));
			b = (e.getKey());
			//System.out.println(" " + BooleanFunction.boolArrAsString(bf.tableOfAccordance.get(e.getKey())));
			break;
		}
		System.out.println();
		System.out.println(b.length);
		for(boolean boo : b) System.out.print(boo==false?0:1);
		System.out.println();
		b = new boolean[15];
		System.out.println(" " + BooleanFunction.boolArrAsString(bf.tableOfAccordance.get(b)));
		
		System.out.println("time taken: " + (System.currentTimeMillis() - start_timer) + " ms");
	}
	
	static void showBFandBGCoordFuncProperties() {
		int n = 15;
		
		BooleanFunction bf = new BooleanFunction("bf");
		bf.init('f', false);
		//bf.printTableOfAccordance();
		
		System.out.println("disbalance:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bf.coordinateFunctions[i].disbalance);
		System.out.println("NL:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bf.coordinateFunctions[i].findNL());
		System.out.println("CorrImmun:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bf.coordinateFunctions[i].findCorrImmun());
		System.out.println("Average spreading deviation:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bf.coordinateFunctions[i].avgSpreadingDeviation());
		
		BooleanFunction bg = new BooleanFunction("bg");
		bg.init('g', false);
		bg.createCoordinateFunctions();
		//bf.printTableOfAccordance();
		
		System.out.println("disbalance:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bg.coordinateFunctions[i].disbalance);
		System.out.println("NL:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bg.coordinateFunctions[i].findNL());
		System.out.println("CorrImmun:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bg.coordinateFunctions[i].findCorrImmun());
		System.out.println("Average spreading deviation:");
		for(int i=0; i<n; i++)System.out.println(i+":\t" + bg.coordinateFunctions[i].avgSpreadingDeviation());
	}
	
	public void printBfSpreading() {
		BooleanFunction bf = new BooleanFunction("bf");
		bf.init('f', true);
		for(CoordinateFunction cf : bf.coordinateFunctions) {
			for(int spr : cf.spreading) {
				System.out.println(spr);
			}
			System.out.println();
		}
	}

}
