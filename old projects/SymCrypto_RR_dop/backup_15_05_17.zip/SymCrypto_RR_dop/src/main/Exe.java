package main;
import polyBasis.*;
public class Exe {
	
	//1000000000000011 = x^15+x+1
	//f(x) = x^N, g(x) = x^M - (15,15) - ������� �������
	
	public static void main(String[] args) {
		long start_timer = System.currentTimeMillis();
		
		// TODO Auto-generated method stub
		/*Gal gal = new Gal("1100101101").pow(new Myr("87F"));
		System.out.println(gal.toPolyString());
		gal = new Gal("11").pow(new Myr("880"));
		System.out.println(gal.toPolyString());*/
		
		BooleanFunction bf = new BooleanFunction("bf");
		bf.init('f');
		//bf.retrieveTOA();
		bf.createCoordinateFunctions();
//		bf.printTableOfAccordance();
		double[] t = bf.coordinateFunctions[0].avgSpreadingDeviation();
		
		/*boolean[] values = {true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,false,false,false,false,false,false,false,true,false,true,false,true,false,true,false,true};
		CoordinateFunction cf = new CoordinateFunction(values, 5);
		System.out.println(cf.findPower());*/
		
		//CoordinateFunction.testSpreading();
		

		/*int[] val = {100, 100, 4, 4, 4, 4, 4, 4, 36, 36, 4, 4, 4, 4, 4, 4, 484, 100, 4, 4, 4, 4, 4, 4, 36, 36, 4, 4, 4, 4, 4, 4};
		val = CoordinateFunction.fastFurieTransform(val, 5);
		for(int i=0; i<val.length; i++) System.out.print(val[i] + " ");
		System.out.println();*/
		
		CoordinateFunction.testSpreading();

		
		
		
		System.out.println("time taken: " + (System.currentTimeMillis() - start_timer) + " ms");
	}

}
