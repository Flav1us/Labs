package main;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

import polyBasis.Gal;
import polyBasis.Myr;
//������������ (n,n)-Bf, 6 �������, ������������ ������������
public class BooleanFunction {
	
	static final int n = 15;
	static final int N = 2175/*==0x87F*/, M = 2176/*==0x880*/;
	//static final int N =0x87F, M = 0x880;
	Map<boolean[], boolean[]> tableOfAccordance;
	boolean[][] coordinateFunctions;
	String instanceName;
	String storedTOAFilename;
	
	public BooleanFunction(String instanceName) {
		this.instanceName = instanceName;
		//createTableOfAccordance();
		storedTOAFilename = "tableOfAccordance_"+instanceName+".bin";
	}
	
	void init(char type) {
		createTableOfAccordance(type);
		retrieveTOA();
		createCoordinateFunctions();
	}
	
	void retrieveTOA() {
		this.tableOfAccordance = retrieveMap(storedTOAFilename);
	}
	
	void createCoordinateFunctions() {
		this.coordinateFunctions = new boolean[n][(int)Math.pow(2, n)];
		Map<boolean[], boolean[]> sortedTOA = BooleanFunction.sortByKey(this.tableOfAccordance);
		int ctr = 0;
		//boolean[] b;
		for(Map.Entry<boolean[], boolean[]> i : sortedTOA.entrySet()) {
			for(int j=0; j<n; j++) {	
				this.coordinateFunctions[j][ctr] = i.getValue()[j];
			}
			ctr++;
		}
	}
	
	/*void printCoordinateFunctions() {
		System.out.println();
		for(int i=0; i<n; i++) {
			for(int j=0; j<(int)Math.pow(2,n); j++) {
//				System.out.print(this.coordinateFunctions[i][j]==false ? 0 : 1);
				if(j%1000==0)System.out.print('.');
			}
			System.out.println();
		}
	}*/
	
	void createTableOfAccordance(char type) throws IllegalArgumentException {
		if (type != 'f' && type != 'g') throw new IllegalArgumentException("Illegal type. Should be 'f' or 'g'.");
		System.out.println("Wait 32 dots:");
		Map<boolean[], boolean[]> tableOA = new HashMap<>();
		String s;
		for(int i=0; i<(int)Math.pow(2,n); i++) {
			//System.out.println("kappa");
			//boolean[] x = new boolean[n], fx = new boolean[n];
			boolean[] x = new boolean[n];
			s = BooleanFunction.lpad(Integer.toBinaryString(i), 15);
			for(int j=0; j<n; j++) {
				x[j] = s.charAt(n-j-1)=='0' ? false : true;
			}
			
			//System.out.println(s);
			/*for(int j = n - s.length()+1; j<n; j++) {
				x[j] = s.charAt(n-j)=='0' ? false : true;
				//fx[j] = s.charAt(n-j-1)=='0' ? false : true;
			}
			for(int j=0; j<n-s.length(); j++) {
				x[j] = false;
				//fx[j] = false;
			}*/
			//fx = f(x);
			//tableOA.put(x, fx);
			if (type == 'f') tableOA.put(x, f(x));
			else if (type == 'g') tableOA.put(x, g(x));
			else throw new IllegalArgumentException("LABEL SHOULDNT APPEAR HERE! Illegal type. Should be 'f' or 'g'.");
			if(i%1000 == 1) System.out.print('.');
		}
		System.out.println();
		try {
			saveMap(tableOA, storedTOAFilename);
		} catch (IOException e) {
			System.out.println("couldn't save tableOfAccordance:\n" + e.getMessage());
		}
	}
	
	boolean[] f(boolean[] x) {
		boolean[] fx = new boolean[n];
		Gal x1 = Gal.booleanArrToGal(x);
		x1 = x1.pow(new Myr(Integer.toHexString(N)));
		fx = x1.toBooleanArr();
		return fx;
	}
	
	boolean[] g(boolean[] x) {
		boolean[] gx = new boolean[n];
		Gal x1 = Gal.booleanArrToGal(x);
		x1 = x1.pow(new Myr(Integer.toHexString(M)));
		gx = x1.toBooleanArr();
		return gx;
	}
	
	void printTableOfAccordance() {
		//String s;
		Map<boolean[], boolean[]> sortedTOA = BooleanFunction.sortByKey(this.tableOfAccordance);
		//System.out.println(sortedTOA.size());
		//int ctr = 0;
		for(Map.Entry<boolean[], boolean[]> e : sortedTOA.entrySet()) {
			//ctr++; System.out.println(ctr);
			for(int i = 0; i<n; i++) {
				System.out.print(e.getKey()[i]==false ? 0 : 1);
			}
			System.out.print("\t");
			for(int i = 0; i<n; i++) {
				System.out.print(e.getValue()[i]==false ? 0 : 1);
			}
			System.out.print("\n");
		}
	}
	
	/*void checkTOA() {
		String s1;
		//for(Map.Entry<boolean[], boolean[]> e : this.tableOfAccordance.entrySet()) {
			for(int i=0; i<(int)Math.pow(2,n); i++) {
				//if(i%1024 == 1) System.out.print('.');
				s1 = BooleanFunction.lpad(Integer.toBinaryString(i), 15);
				System.out.println(s1 + "\t" + this.tableOfAccordance.get(new Gal(s1).toBooleanArr()));
			}
			System.out.println("OK");
		//}
	}*/
	
	
	
	public static String lpad(String s, int n) {
		StringBuilder s1 = new StringBuilder();
		for(int i=0; i<n-s.length(); i++) {
			s1.append('0');
		}
		s1.append(s);
	    return s1.toString();  
	}
	
	//public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map) {
	public static Map<boolean[], boolean[]> sortByValue(Map<boolean[], boolean[]> map) {
	    return map.entrySet()
	              .stream()
	              //.sorted(Map.Entry.comparingByValue(Collections.reverseOrder()))
	              .sorted(Map.Entry.comparingByValue(new LexicographicComparator()))
	              .collect(Collectors.toMap(
	                Map.Entry::getKey, 
	                Map.Entry::getValue, 
	                (e1, e2) -> e1, 
	                LinkedHashMap::new
	              ));
	}
	
	public static Map<boolean[], boolean[]> sortByKey(Map<boolean[], boolean[]> map) {
	    return map.entrySet()
	              .stream()
	              //.sorted(Map.Entry.comparingByValue(Collections.reverseOrder()))
	              .sorted(Map.Entry.comparingByKey(new LexicographicComparator()))
	              .collect(Collectors.toMap(
	                Map.Entry::getKey, 
	                Map.Entry::getValue, 
	                (e1, e2) -> e1, 
	                LinkedHashMap::new
	              ));
	}
	
	
	public static void saveMap(Map<boolean[], boolean[]> map, String filename) throws IOException {
		try {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename));
			out.writeObject(map);
			out.close();
		} catch (FileNotFoundException e) {
			System.out.println("looks like file not found:\n" + e.getMessage());
		}
	}
	
	
	public static Map<boolean[], boolean[]> retrieveMap(String filename) {
		Map<boolean[], boolean[]> map = null;
		try {
	         FileInputStream fileIn = new FileInputStream(filename);
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         map = (Map<boolean[], boolean[]>) in.readObject();
	         in.close();
	         fileIn.close();
	      }catch(IOException i) {
	         i.printStackTrace();
	         return null;
	      }catch(ClassNotFoundException c) {
	         System.out.println("Map class not found");
	         c.printStackTrace();
	         return null;
	      }
		return map;
	}
	
	
}


class LexicographicComparator implements Comparator<boolean[]> {
    @Override
    public int compare(boolean[] a, boolean[] b) {
        for(int i=0; i<a.length; i++) {
        	if (a[i] == false && b[i] == true) return -1;
        	else if (a[i] == true && b[i] == false) return 1;
        }
        return 0;
    }
}
